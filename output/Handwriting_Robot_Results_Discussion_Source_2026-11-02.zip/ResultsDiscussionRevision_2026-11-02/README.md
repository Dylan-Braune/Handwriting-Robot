# Handwriting Robot report source

Open full_report.tex in this folder. Compile with pdfLaTeX, BibTeX and two further pdfLaTeX passes, or run python build_report.py. The PDF is produced in .build/full_report.pdf.

This archive contains the local source and assets actually used by the verified build. No generated build directory or historical drafts are included. The template remains the supplied epr400.cls. A small compatibility file handles the supplied command typo and engine-specific microtype settings.

Literature, Approach and Design wording are preserved. Two missing math delimiters in the reproduction pseudocode were repaired. Results, Discussion and supporting appendices are revised. The Conclusion is unchanged and still contains older values. See the separate revision notes before submission.
