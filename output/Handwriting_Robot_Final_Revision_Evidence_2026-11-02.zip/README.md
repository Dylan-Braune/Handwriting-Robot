# Supporting evidence

revision_notes.md describes the latest report. laptop_timings contains the existing thirteen-page, three-repeat experiment and the L1 to L13 source-page index. The original Report measurement folders retain the fourteen-page batching/library comparison and ODROID logs. These are separate populations and platforms. No timing experiment was rerun.

The previous native geometric banks and complete transcribed tables remain available. The compile source ZIP contains the updated VisualTests assets and is independent of this evidence ZIP.
