# Final report source

Open full_report.tex. Run python build_report.py, or use pdfLaTeX, BibTeX and two more pdfLaTeX passes. Output is .build/full_report.pdf. This archive contains the verified local build inputs.

QTP1 is preserved, QTP2 is restored from the supplied report, laptop timings and conditional acceleration estimates are included, Discussion is three pages, and Conclusion is complete. All twelve supplied VisualTests PDFs are installed. No new tests or training were run. See the separate revision notes for provenance.
