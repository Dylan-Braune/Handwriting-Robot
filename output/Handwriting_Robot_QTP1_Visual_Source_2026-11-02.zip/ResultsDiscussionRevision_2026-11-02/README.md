# Report source

Open full_report.tex. Run python build_report.py, or use pdfLaTeX, BibTeX and two further pdfLaTeX passes. The local build creates .build/full_report.pdf. This archive contains only the verified build inputs, with no historical build directory.

This revision makes both classifier tests explicit in QTP1, retains geometric verification, removes redundant figures and condenses the evidence appendix. All measurements are unchanged. See the separate revision notes.
