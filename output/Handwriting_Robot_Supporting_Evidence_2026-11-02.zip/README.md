# Supporting report evidence

ResultsEvidence/measurements/RESULTS_PROVENANCE.md is the original result index.
ResultsEvidence/measurements/outputs contains the measured JSON records and
ResultsEvidence/measurements/raw contains the preserved ODROID log.
DerivedRecords contains both confusion matrices as raw counts and row percentages,
all physical paired-line records and transcriptions of the supplied training logs.
The writer order is 150, 152, 153, 384, 552, 588, A, B, O, T, Y.
A=abhinav, B=dylan, O=owen, T=thiya, Y=yeukita.

Model binaries are not duplicated here. The manifest retains their SHA-256 hashes.
The original personal/IAM datasets remain in the project. Full physical-page images
are included in the compilation source ZIP as the appendix figure dependencies.
Historical scripts retain their original data-path assumptions. RevisionScripts
records the report derivation script and is intended to run from the project root,
not as part of compilation. No script needs to run to compile the supplied source.
