# Retained evidence

No new analysis was run for this report revision. The Report folders retain the original measurement provenance, native crops, reference banks, scores and scripts. revision_statistics retains the existing derived statistics and all 70 dimensional readings.

visual_revision/retained_full_records.tex preserves the full transcribed per-line, per-word, dimensional and training-log tables removed from the PDF to shorten its appendix. It is an evidence record, not another report to compile. revision_notes.md describes the current document layout.

The older plot generator remains as historical reproducibility material. It is not needed to compile the source ZIP or read these records.
