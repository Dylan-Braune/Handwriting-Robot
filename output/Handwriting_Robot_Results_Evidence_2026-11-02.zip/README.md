# Supporting result evidence

revision_statistics contains the 70 supplied dimensional readings, derived summaries, geometric resampling results and figure previews. revision_tools contains the plot generator, typography check and protected-source audit. The Report folders retain the original classifier/timing provenance archive and the complete geometric studies, including native crops, scores, reference banks and scripts. No checkpoint weights or new training runs are included.

The plot generator is intended to run from the original repository root. To recreate those paths in another workspace, extract the Report evidence folders there and place the source archive folder at Report/ResultsDiscussionRevision_2026-11-02. The generator writes previews to tmp/results_discussion_revision/evidence and new figure PDFs to the report Figures folder. Install NumPy, SciPy, OpenCV, Matplotlib and Pillow, with Times New Roman available. The typography audit additionally uses pypdf. The scripts do not operate the gantry or start training.

See each study's README and PROTOCOL for its original execution details. Existing developer-host analyses and ODROID logs retain their documented provenance.
