# Figures and evidence to complete

This register records actual requests, not completed tests. The user will provide
diagrams/examples or decide that an illustration is unnecessary. Continue other
writing while requests are pending. Formal full-system results and QTPs remain in
Results, not here.

## High priority system overview

**User response received:** the user will make this later with proper guidance.
It is an important diagram and must remain on the completion list.

### Hardware overview — Figure in 3.2

Filename: `Figures/design-hardware-overview.pdf` (vector preferred).

Suggested arrangement: camera and page at left; ODROID in the middle; two A4988
drivers with X/Y motors at right; pen-motor switching circuit below the drivers;
four axis end stops and one pen-state switch below the ODROID; power supplies
along the bottom. Keep the physical pen/gantry visible as the output assembly.

Show:

- Camera image data → ODROID, labelled USB.
- ODROID STEP/DIR → each A4988; each driver → its two motor windings.
- ODROID control → BC337/pen switching stage → geared motor and cam.
- X MIN, X MAX, Y MIN, Y MAX and PEN UP feedback → ODROID inputs.
- Confirmed 24 V rail → motor-driver supply inputs.
- Actual ODROID and pen supplies when confirmed, not invented conversion stages.
- Common logic reference, with a legend distinguishing data/control from power.

This overview is not a complete circuit schematic. Leave resistor values and
physical pin numbering for the electrical drawing. Label the Y motor as driving
both side belts through the cross-shaft, not as two separate Y motors.

### Processing overview — Figure in 3.2

Filename: `Figures/design-processing-overview.pdf`.

Use three paths with stored artefacts between them:

1. Labelled page/line images → preparation → network training → model weights;
   labelled lines + reader → glyph/style extraction → stored profiles.
2. Photograph → conditioning and line segmentation → reader + writer model →
   recognised text and writer, with per-line information.
3. Digital text + selected profile → glyph layout and candidate selection → pen
   trajectory → G-code → gantry. Show reader/writer models feeding candidate scoring.

Distinguish preparation/training from request-time processing. Do not imply that
an unlabelled classification request trains the models or builds a new profile.

## Other requested figures

| Location | Filename | Required content | Status |
|---|---|---|---|
| 3.3.1 | `design-gantry-assembly.jpg` | Whole assembled gantry with custom brackets, rails, shared shaft, belt fastening/tensioning and page restraint labelled | Requested |
| 3.3.5 | `design-complete-circuit.pdf` | Actual complete wiring, rails, GPIO mapping, driver configuration and component values, protection and decoupling | Requested |
| 3.3.6 | `design-camera-arrangement.jpg` | Actual camera mount, page support, working distance and illumination direction | Requested |
| 3.4.1 | `design-segmentation-stages.pdf` | One real page through ratio image, mask, cleaning, centres/seams and final crops | Pending source example |
| 3.4.6 | `design-segmentation-variation.pdf` | Same handwriting in normal/uneven lighting and small rotation; selected crops and actual observations | Requested, not a QTP |
| 3.5.2 | `design-network-architecture.pdf` | 64×640 input, 2/4/6 convolution stages, pooling, 128 features ×160 frames, reader and writer branches | Pending drawing |
| 3.5.4 | `design-stroke-normalisation.pdf` | Original, binary, skeleton and fixed-width crop segments | Generated from existing data at fraction 0.14 |
| 3.6.1 | `design-glyph-alignment.pdf` | Known text, initial CTC locations, refined cuts, resulting glyphs; connected example | Asked whether existing figures are available |
| 3.6.3 | `design-glyph-quality.pdf` | Retained/rejected variants, reasons, medoid and accepted prototype if present | Pending real example |
| 3.6.5 | `design-glyph-joining.pdf` | Entry/exit, body versus detached mark, accepted and rejected connector cases | Asked for existing worked example |
| 3.6.6 | `design-candidate-selection.pdf` | Few candidates for fixed text/profile, A/P/J scores, selected candidate and repair/fallback sources | Pending logged example |

Existing axes, pen mechanism, prototype circuit, switch circuit and square/triangle
images were retained from the Prism export. Final circuit images must represent
the installed wiring, not a generic illustration or an assumed supplier variant.

## Hardware facts still needed

- Which axis is represented by the recorded 0.950 kg moving mass; actual resistance
  measurement; torque data for 42BYGH40-01 under applicable drive conditions.
- Driver sense resistors and measured Vref, current setting and cooling.
- Pen-motor supply and running/startup current; installed flyback diode and base
  pull-down; safe interface rating. Do not infer motor current from supply limit.
- Actual ODROID supply, supply distribution and local driver decoupling.
- Operating condition and included loads for the 0.35 A supply reading.
- Camera make/model, capture resolution, mounting distance and dimensions.
- Final calibrated step counts/scales if they are to be stated beyond code defaults.

## Classification evidence still needed

- Actual training source, epochs, counts, machine and final checkpoint identities.
- Final stroke-normalisation width and its matching training/inference use.
- Matched ink/shape comparison on original and reproduced crops to demonstrate the
  design rationale; separate confidence from correctness and independent judgement.
- Matched trained-model comparison for first-principles/framework reader and writer
  models. The small archived study is not the final recognition result.
- Confirm independence of profile-building and evaluation inputs.

## Archived numerical comparison included

Producer: `Software/CleanPipeline2/testing/torchtrain.py`, `DoCheck`.
Output: `Software/CleanPipeline2/testing/results/trainvs/equivalence.json`.
The producer was inspected, but the experiment was not rerun in this revision.

Two random inputs of size 1×64×640; float64; matching initialized parameters;
text CTC and 13-class writer cross-entropy; dropout disabled for writer comparison.
`forward` is max absolute logit difference divided by the greater max magnitude
(floor 1e-8); `loss` is absolute loss difference; `worstGrad` ranks relative L2
gradient differences excluding tensors whose max gradient magnitude is below 1e-6.
The archive keeps those excluded tensors for inspection.

These details are stated in the draft so the table cannot be mistaken for a
final-model classification result. Relevance to the final submitted revision
still requires confirmation.

## Reasons for remaining limitations

The draft identifies remedies where supported by the design, but does not invent
why they were not implemented. Ask the user for the actual constraint when filling
those passages: data availability, measured trade-off, hardware constraints or
time may be relevant, but none should be asserted by default.
